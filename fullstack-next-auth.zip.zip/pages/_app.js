import { useEffect } from 'react'; // <-- add this
import { Toaster } from 'react-hot-toast';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../styles/globals.css';
import '../styles/footer.css';

import Navbar from '../components/NavbarTemp';
import Footer from '../components/Footer';

import { SessionProvider } from 'next-auth/react';

function MyApp({ Component, pageProps: { session, ...pageProps } }) {
  useEffect(() => {
    // Dynamically import bootstrap's JS (needed for navbar toggler, dropdown, etc.)
    require('bootstrap/dist/js/bootstrap.bundle.min.js');
  }, []);

  return (
    <SessionProvider session={session}>
      <Navbar />
      <main>
        <Component {...pageProps} />
        <Toaster position="top-center" reverseOrder={false} toastOptions={{ duration: 4000 }} />
      </main>
      <Footer />
    </SessionProvider>
  );
}

export default MyApp;
