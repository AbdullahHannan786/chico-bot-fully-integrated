

export default function Contact(){
    return(
        <>
      
        <div className="container mt-5 ">
        <h1 className="text-center mb-3" >CONTACT US</h1>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Repudiandae veniam, libero dolores incidunt fugit nemo, eos temporibus odit nesciunt eius consequatur veritatis. Aperiam fugiat repudiandae a quidem reprehenderit. Aliquid, sapiente.</p>
        </div>
        </>
    );
}