import { useSession } from "next-auth/react";
import { useState, useEffect } from "react";
import toast from "react-hot-toast";
import Image from "next/image";
import '../styles/profile.css';

export default function Profile() {
  const { data: session } = useSession();
  const [userData, setUserData] = useState(null);
  const [editing, setEditing] = useState(false);
  const [formData, setFormData] = useState({});
  const [avatarFile, setAvatarFile] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      if (!session?.user?.email) return;
      try {
        const res = await fetch(`/api/forms/${session.user.email}`);
        if (!res.ok) throw new Error("Failed to fetch");
        const data = await res.json();
        setUserData(data);
        setFormData(data);
      } catch (err) {
        toast.error("Could not load profile");
      }
    };
    fetchData();
  }, [session]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleUpdate = async () => {
    try {
      const res = await fetch(`/api/forms`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: session.user.email, ...formData }),
      });
      if (!res.ok) throw new Error("Update failed");
      const updated = await res.json();
      setUserData(updated);
      toast.success("Profile updated");
      setEditing(false);
    } catch (err) {
      toast.error("Error updating profile");
    }
  };

  const handleAvatarUpload = async () => {
    if (!avatarFile) return;
    const form = new FormData();
    form.append("avatar", avatarFile);
    form.append("email", session.user.email);
    const res = await fetch("/api/upload-avatar", { method: "POST", body: form });
    if (res.ok) {
      toast.success("Avatar uploaded");
    } else {
      toast.error("Upload failed");
    }
  };

  if (!userData) return <p className="loading">Loading your data...</p>;

  return (
    <div className="profile-page">
      <h1 className="title">My Profile</h1>

      <div className="profile-card">
        <div className="avatar-section">
          <Image
            src={userData.avatar ? `/uploads/avatars/${userData.avatar}` : "/default-avatar.png"}
            alt="avatar"
            width={100}
            height={100}
            className="avatar-img"
          />
          <input type="file" onChange={(e) => setAvatarFile(e.target.files[0])} />
          <button onClick={handleAvatarUpload}>Upload Avatar</button>
        </div>

        <div className="fields-grid">
          {["name", "email", "phone", "city", "degree", "age"].map((field) => (
            <div className="field-box" key={field}>
              <label>{field.charAt(0).toUpperCase() + field.slice(1)}:</label>
              <input
                name={field}
                value={formData[field] || ""}
                onChange={handleChange}
                disabled={!editing}
              />
            </div>
          ))}
        </div>

        <div className="edit-btn-box">
          {editing ? (
            <button className="save-btn" onClick={handleUpdate}>Save</button>
          ) : (
            <button className="edit-btn" onClick={() => setEditing(true)}>Edit Profile</button>
          )}
        </div>
      </div>

      <style jsx>{`
        .profile-page {
          padding: 30px;
          font-family: 'Segoe UI', sans-serif;
          background: linear-gradient(to bottom right, #edf0f5, #f8f9fb);
        }

        .title {
          font-size: 32px;
          font-weight: bold;
          margin-bottom: 20px;
        }

        .profile-card {
          background: white;
          border-radius: 12px;
          padding: 30px;
          box-shadow: 0 4px 15px rgba(0,0,0,0.08);
          max-width: 800px;
          margin: auto;
        }

        .avatar-section {
          text-align: center;
          margin-bottom: 30px;
        }

        .avatar-img {
          border-radius: 50%;
          margin-bottom: 10px;
        }

        .fields-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
          gap: 20px;
        }

        .field-box {
          display: flex;
          flex-direction: column;
        }

        .field-box label {
          font-size: 14px;
          font-weight: 600;
          margin-bottom: 5px;
        }

        .field-box input {
          padding: 10px;
          border-radius: 8px;
          border: 1px solid #ccc;
          background: #f5f5f5;
        }

        .edit-btn-box {
          text-align: center;
          margin-top: 30px;
        }

        .edit-btn, .save-btn {
          padding: 10px 20px;
          font-weight: bold;
          border: none;
          border-radius: 8px;
          cursor: pointer;
          background: #6c63ff;
          color: white;
        }

        @media(max-width: 600px) {
          .title {
            text-align: center;
          }
        }
      `}</style>
    </div>
  );
}
