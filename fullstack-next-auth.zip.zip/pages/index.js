import { useSession } from 'next-auth/react';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import toast from 'react-hot-toast';

export default function Home() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [form, setForm] = useState({ name: '', age: '', city: '', degree: '', phone: '' });
  const [userForm, setUserForm] = useState(null);
  const [editMode, setEditMode] = useState(false);

  const fetchUserForm = async () => {
    const res = await fetch(`/api/forms?userId=${session.user.id}`);
    const data = await res.json();
    if (data.success && data.forms.length > 0) {
      const uf = data.forms[0];
      setUserForm(uf);
    }
  };

  useEffect(() => {
    if (session?.user?.id && session?.user?.role !== "admin") {
      fetchUserForm();
    }
  }, [session]);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (form.name.length < 2) return toast.error('Name must be at least 2 characters');
    if (!form.age || form.age < 10 || form.age > 100) return toast.error('Age must be between 10 and 100');
    if (!form.city.trim()) return toast.error('City is required.');
    if (!form.degree.trim()) return toast.error('Degree is required.');

    const isAdmin = session?.user?.role === "admin";

    const method = isAdmin
      ? 'POST'
      : editMode
      ? 'PUT'
      : userForm
      ? 'PUT'
      : 'POST';

    const url = isAdmin
      ? '/api/forms'
      : editMode
      ? `/api/forms/${userForm._id}`
      : userForm
      ? `/api/forms/${userForm._id}`
      : '/api/forms';

    try {
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, userId: session.user.id }),
      });

      const data = await res.json();
      if (data.success) {
        toast.success(editMode ? 'Form updated successfully!' : 'Form submitted successfully!');

        if (isAdmin) {
          // Admin can keep adding forms
          setForm({ name: '', age: '', city: '', degree: '', phone: '' });
        } else {
          // Normal user flow: reset and hide form
          setEditMode(false);
          setForm({ name: '', age: '', city: '', degree: '', phone: '' });
          fetchUserForm();
        }
      } else {
        toast.error('Something went wrong!');
      }
    } catch (error) {
      toast.error('An error occurred while saving the form.');
    }
  };

  const handleEditClick = () => {
    if (!userForm) return;
    setEditMode(true);
    setForm(userForm); // populate fields with saved data
  };

  if (status === 'loading') return <div className="text-center mt-5">Loading...</div>;

  if (!session) {
    return (
      <div className="d-flex flex-column justify-content-center align-items-center" style={{ height: '80vh' }}>
        <h1 className="mb-4 text-primary">Welcome to My Practice Web</h1>
        <p className="mb-4 fs-5 text-muted">Please sign up or log in to continue</p>
        <div className="d-flex gap-3">
          <button className="btn btn-primary btn-lg" onClick={() => router.push('/signup')}>Sign Up</button>
          <button className="btn btn-outline-primary btn-lg" onClick={() => router.push('/login')}>Log In</button>
        </div>
      </div>
    );
  }

  const isAdmin = session.user.role === "admin";

  return (
    <div className="container py-5">
      <h1 className="text-center">Welcome back, {session.user.name}</h1>
      <p className="text-center">You are logged in and ready to use the app.</p>

      {/* Show form only if: admin OR (normal user with no form) OR editMode */}
      {isAdmin || editMode || !userForm ? (
        <form onSubmit={handleSubmit} className="p-4 border rounded bg-light mt-4">
          {['name', 'age', 'city', 'degree', 'phone'].map((field) => (
            <div className="mb-3" key={field}>
              <label className="form-label text-capitalize">{field}</label>
              <input
                type={field === 'age' ? 'number' : 'text'}
                className="form-control"
                name={field}
                value={form[field]}
                onChange={handleChange}
                required
              />
            </div>
          ))}
          <button type="submit" className="btn btn-success w-100">
            {isAdmin
              ? 'Submit Form'
              : editMode
              ? 'Update Form'
              : userForm
              ? 'Update Form'
              : 'Submit Form'}
          </button>
        </form>
      ) : (
        // Show Edit My Form button only when normal user has an existing form
        <div className="text-center mt-3">
          <button className="btn btn-warning" onClick={handleEditClick}>
            Edit My Form
          </button>
        </div>
      )}
    </div>
  );
}
