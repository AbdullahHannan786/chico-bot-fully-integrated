// next.config.js
const nextConfig = {
  api: {
    bodyParser: false, // Important for file uploads
  },
};

export default nextConfig;
