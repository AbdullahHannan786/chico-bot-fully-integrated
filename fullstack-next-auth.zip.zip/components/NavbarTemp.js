"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useSession, signOut } from "next-auth/react";
import toast from "react-hot-toast";

export default function NavbarTemp() {
  const pathname = usePathname();
  const { data: session } = useSession();

  const handleLogout = async () => {
    const confirmed = window.confirm("Are you sure you want to logout?");
    if (confirmed) {
      await signOut({ redirect: false });
      toast.success("Logged out successfully!");
      window.location.href = "/"; // Ensure redirect works on mobile
    }
  };

  return (
    <nav className="navbar navbar-expand-lg bg-body-tertiary">
      <div className="container-fluid">
        <Link
          className={`navbar-brand ${pathname === "/" ? "active" : ""}`}
          href="/"
        >
          Home
        </Link>

        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav me-auto">
            <li className="nav-item">
              <Link
                className={`nav-link ${pathname === "/about" ? "active" : ""}`}
                href="/about"
              >
                About Us
              </Link>
            </li>
            <li className="nav-item">
              <Link
                className={`nav-link ${
                  pathname === "/contact" ? "active" : ""
                }`}
                href="/contact"
              >
                Contact
              </Link>
            </li>

            {session?.user?.role === "admin" && (
              <li className="nav-item">
                <Link
                  className={`nav-link ${
                    pathname === "/admin" ? "active" : ""
                  }`}
                  href="/admin"
                >
                  Admin Panel
                </Link>
              </li>
            )}

            {/* ✅ New "My Profile" link for all logged-in users */}
            {session && (
              <li className="nav-item">
                <Link
                  className={`nav-link ${
                    pathname === "/profile" ? "active" : ""
                  }`}
                  href="/profile"
                >
                  My Profile
                </Link>
              </li>
            )}
          </ul>

          <ul className="navbar-nav ms-auto">
            {!session ? (
              <>
                <li className="nav-item">
                  <Link className="nav-link" href="/signup">
                    Signup
                  </Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" href="/login">
                    Login
                  </Link>
                </li>
              </>
            ) : (
              <li className="nav-item">
                <button
                  className="btn btn-outline-danger"
                  onClick={handleLogout}
                >
                  Logout
                </button>
              </li>
            )}
          </ul>
        </div>
      </div>
    </nav>
  );
}
